import java.time.LocalDate;
import java.util.List;

public class App {
    public static void main(String[] args){

        //Remplissage de  notre boutique
                
                //Creation de l'instance Boutique 
                Boutique boutique1 = new Boutique();

                // //Creation et ajout des 03 produits 
                    // Produit produit1 = new Produit("Calculatrice","Calculatrice pas chère");
                    // Produit produit2 = new Produit("Crème","Crème de qualité");
                    // Produit produit3 = new Produit("Ananas","Ananas bon marcher");
                        
                    // boutique1.addProduit(produit1);
                    // boutique1.addProduit(produit2);
                    // boutique1.addProduit(produit3);

                ProduitElectronique produitElectronique = new ProduitElectronique("Calculatrice", "Calculatrice pas chère",20, 12);
                ProduitAlimentaire produitAlimentaire = new ProduitAlimentaire("Ananas", "Ananas bon marcher",10 , LocalDate.of(2024, 12, 04));
                ProduitBoisson produitBoisson = new ProduitBoisson("Youki","youki fraîche",15 , 60);

                boutique1.addProduit(produitElectronique);
                boutique1.addProduit(produitAlimentaire);
                boutique1.addProduit(produitBoisson);

                //Récupération des produits du magasin 
            List<Produit> produits = boutique1.getProduits();

            // Affichage des produits qu'on peut acheter via boucle
            System.out.println("Produits disponibles dans la boutique :");
            for (Produit produit : produits) {
                System.out.println(produit.getNom() + " - " + produit.getDescription());
            }
        //Affichage de notre boutique avec la methode afficherStock()
        
            System.out.println("Produits appartenant à la boutique :");
            boutique1.afficherStock();

        // Test du panier

            //Creation de l'objet Panier
            Panier panier1 = new Panier();

            //Ajout de produits
            Produit produit1 = new Produit("Calculatrice","Calculatrice pas chère", 20);
             Produit produit2 = new Produit("Crème","Crème de qualité", 25);
             Produit produit3 = new Produit("Ananas","Ananas bon marcher", 10);

            panier1.ajouterProduit(produit1);
            panier1.ajouterProduit(produit2);
            panier1.ajouterProduit(produit3);

            //Affichage du prix total du panier
            System.out.println("Prix total du panier : "+ panier1.prixTotalPanier());

    }
}
