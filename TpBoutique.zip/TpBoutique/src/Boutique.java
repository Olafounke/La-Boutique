import java.util.ArrayList;
import java.util.List;

public class Boutique {
    private List<Produit> produits;

    // Constructeur
    public Boutique() {
        this.produits = new ArrayList<>();
    }

    // Methode pour ajouter un produit
    public void addProduit(Produit produit) {
        produits.add(produit);
    }

    // Methode pour obtenir la liste des produits disponibles dans la boutique
    public List<Produit> getProduits() {
        return produits;
    }

    // Affichage du stock via afficher()
    public void afficherStock() {
        for (Produit produit : produits) {
            produit.afficher();
        }
    }
}
