public class ProduitBoisson extends Produit{

    private int quantite;

    //Constructeur
    public ProduitBoisson(String nom, String descripton, int prix, int quantite) {
        super(nom, descripton,prix);
        this.quantite = quantite;
    }
    
    //Methode afficher spécifique
    @Override
    public void afficher(){
        super.afficher();
        System.out.println("Quantité : "+ quantite +"cl");
    }
}
