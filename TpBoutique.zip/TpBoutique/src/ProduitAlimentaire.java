import java.time.LocalDate;

public class ProduitAlimentaire extends Produit{
    private LocalDate dateExpiration;

    //Constructeur
    public ProduitAlimentaire(String nom, String descripton, int prix, LocalDate dateExpiration) {
        super(nom, descripton,prix);
        this.dateExpiration=dateExpiration;
    }

    //Methode afficher spécifique
    @Override
    public void afficher(){
        super.afficher();
        System.out.println("Date d'expiration : "+ dateExpiration);
    }
}
