public class ProduitElectronique extends Produit {

    private int dureeGarantie;

    //Constructeur
    public ProduitElectronique(String nom, String descripton, int prix, int dureeGarantie) {
        super(nom, descripton,prix);
        this.dureeGarantie = dureeGarantie;
    }

    //Methode afficher spécifique
    @Override
    public void afficher(){
        super.afficher();
        System.out.println("La durée de garantie est : "+ dureeGarantie +"mois");
    }
}
