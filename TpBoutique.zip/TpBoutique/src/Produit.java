public class Produit {
    private String nom;
    private String description;
    private int prix; // Ajout de l'attribut prix

    //Constructeur
    public Produit(String nom, String descripton, int prix){
        this.nom = nom;
        this.description= descripton;
        this.prix = prix;
    }

    //Getter Setter
    public String getNom(){
        return this.nom;
    }

    public void setNom(String nom){
        this.nom = nom;
    }

    public String getDescription(){
        return this.description;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public int getPrix(){
        return this.prix;
    }

    public void setPrix(int prix){
        this.prix = prix;
    }

    // Affichage des infirmations du produit
    public void afficher(){
        System.out.println("Nom du produit :" + nom);
        System.out.println("Description du produit :" + description);
        System.out.println("Prix du produit : " + prix + "euro");//Inclusion du prix
    }
}
